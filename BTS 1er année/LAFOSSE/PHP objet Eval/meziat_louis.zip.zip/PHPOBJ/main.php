<?php

$person = new Personne;

        
        class Personne

{

  private $_Nom;

  private $_Prenom;

  private $_Age;

  private $_Profession;
  
  private $_sexe;
  
  private $_passion;
  
  private $_nationalite;

        

 public function entrerVotreNom()
 {
   $this->_Nom = $Nom;
   echo "$Nom";
 }

  public function entrerVotrePrenom()
          
  {
   $this->_Prenom = $Prenom;
   echo "$Prenom";
  }

  public function entrerVotreAge()
 {
   $this->_Age = $Age;
   echo "$Age";
 }
 
 public function entrerVotreProfession()
 {
   $this->_Profession = $Profession;
   echo "$Profession";
 }
}
