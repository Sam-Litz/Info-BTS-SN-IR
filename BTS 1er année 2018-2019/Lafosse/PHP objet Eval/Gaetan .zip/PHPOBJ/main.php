<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
         <form  method="POST" action="detail.php">
        <table border="0" width="100%">
            <tr><td><p>Merci de saisir vos coordonnées</p></td></tr>
         
            <tr><td>Nom : <input type="text" value="" name="Nom" placeholder=""/><br><br></td></tr>
            <tr><td>Prénom : <input type="text" value="" name="Pre" placeholder=""/><br><br></td></tr>
            <tr><td> Age : <input type="text" value="" name="Age" placeholder=""/><br><br></td></tr>
            <tr><td>Profession : <input type="text" value="" name="Pro" placeholder=""/><br><br></td></tr>
        
         <br>
          
         
             <tr><td><p>Quel est votre sexe ?</p><br></td>
         
             <tr><td><input type="radio" value="femme" name="Fe"> Feminin <br></td></tr>
             <tr><td><input type="radio" value="homme" name="Ho"> Masculin <br></td></tr>
         
         
         
             <tr><td><p>Quelles sont vos passions ?</p><br></td></tr>
         
             <tr><td>Musique <input type="checkbox" name="Mu" value="Musique"><br/></td></tr>
             <tr><td>Sport <input type="checkbox" name="Sport" value="Sport"><br/></td></tr>
             <tr><td>Jeux vidéo <input type="checkbox" name="Jeux" value="Jeux vidéo" ><br/></td></tr>
         
         
         
             <tr><td><p>Quelle est votre nationalité ?</p></td></tr>
         
         <tr><td><select style="width:100px;"><option name="Na" value="Française">Française</option>
        <option value="">Allemande</option>
        <option value="">Espagnole</option>
        <option value="">Anglaise</option>
        <option value="">Italienne</option>
        <option value="">Portugaise</option></select></td></tr>
       
         <tr><td align="center" ><input type="submit" value="Valider"/></td></tr>
         </table>
         
         </form>
         
         
         
         
         
         
         
        
    </body>
</html>
