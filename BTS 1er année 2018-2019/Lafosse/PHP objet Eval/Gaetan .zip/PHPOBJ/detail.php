<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       
        <p>Merci Voici votre fiche personnelle</p><br>
        
        Vous vous appelez <?php echo htmlspecialchars($_POST['Nom']);?> <?php echo htmlspecialchars($_POST['Pre']);?> et vous avez <?php echo (int)$_POST['Age']; ?> ans.<br><br>
        
        
        Vous êtes un <?php echo htmlspecialchars($_POST['Ho']);?>, vous aimez la <?php echo htmlspecialchars($_POST['Mu']);?> et le <?php echo htmlspecialchars($_POST['Sport']);?> et vous êtes de nationalité <?php echo htmlspecialchars($_POST['Na']);?>.

       
    </body>
</html>
