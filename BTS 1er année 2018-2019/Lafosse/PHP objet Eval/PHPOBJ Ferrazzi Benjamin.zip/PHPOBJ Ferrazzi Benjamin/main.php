<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Formulaire</title>
    </head>
    <body>
        <table border="0">
            <thead>
                <tr>
                    <th><h1>Merci de saisir vos coordonnées</h1></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Nom :           <input type="text" name="" value="" /><br><br>
                        Prénom :        <input type="text" name="" value="" /><br><br>
                        Age :           <input type="text" name="" value="" /><br><br>
                        Profession :    <input type="text" name="" value="" /><br><br></td>
                </tr>
                <tr>
                    <td><h3>Quel est votre sexe ?</h3><input type="radio" id="Masculin" name="sexe" value="Masculin"> Masculin<br>
                                                           <input type="radio" id="Feminin" name="sexe" value="Feminin"> Feminin</td>
                </tr>
                <tr>
                    <td><h3>Quelles sont vos passions ?</h3>Musique <input type="checkbox" name="" value="ON" /><br>
                                                            Sport <input type="checkbox" name="" value="ON" /><br>
                                                            Jeu Vidéo <input type="checkbox" name="" value="ON" /><br><br>
                                                            <h3>Quelle est votre nationalité ?<select name="">
                                                                    <option>Francais</option>
                                                                    <option>Anglais</option>
                                                                    <option>Allemand</option>
                                                                    <option>Italien</option>
                                                                    <option>Russe</option>
                                                                </select></td>
                                                                <td><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><input type="submit" value="Afficher" /></td>
                </tr>
            </tbody>
        </table>

        <?php
        ?>
    </body>
</html>
