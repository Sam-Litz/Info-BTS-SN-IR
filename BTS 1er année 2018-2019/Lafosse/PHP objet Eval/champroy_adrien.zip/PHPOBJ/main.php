<html>
    <head>
        <title>main</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
    <body>
<form name="Authentification" method="POST" action="php/formulaire.php">
            <center> <table  border="0" width="85%">
                    <tr>
                    <td align="left">
                        Merci de saisir vos coordonnées
                        <br/>
                        <br/>
                    Nom : <input type="text" value="" name="nom" required=""/>
               <br/> 
               <br/>
                    Prénom : <input type="text" value="" name="prenom"  required=""/>
               <br/> 
               <br/>
                    Age : <input type="text" value="" name="age"  required=""/>
               <br/> 
               <br/>
                    Profession : <input type="text" value="" name="profession" required=""/>
               <br/> 
               <br/>
               <br/>
                    Quel est votre sexe ?<br/><br/>
                    <input type="radio" name="sexe" value="feminin" id="feminin"> Feminin 
                    <br/>
                    <br/>
                    <input type="radio" name="sexe" value="masculin" id="masculin"> Masculin
             <br/> 
             <br/>
                    
                    </select>
                    <br/>
                    </td>
                    </tr>
                    <tr>
                    <td align="left">
                Quelles sont vos passion ?
                        <br/>
                        <br/>
                        Musique<input type="checkbox" name="activite" value="musique">  
                        <br/> 
                        <br/>
                        Sport<input type="checkbox" name="activite" value="sport">
                        <br/> 
                        <br/>
                        Jeux vidéo  <input type="checkbox" name="activite" value="jeux-video"> 
                        <br/> 
                        <br/>
                        Quelle est votre nationalité ?<br/><br/><select name="pays">
                         <option value="allemagne">Française</option>
                         <option value="belgique">Belge</option>
                         <option value="espagne">Espagnagnol</option>
                         <option value="france">Allemande</option>
                         <option value="italie">Italienne</option>
                         <option value="portugal">Portugaise</option>
                         <option value="royaume-uni">Anglaise</option>
                    </td>
                    </tr>
                    </table>
                <table align="center" width="50%" border="0">
                    <tr>
                    <td align="left"><br/><br/>
                        <input type="submit" value="Valider"/>
                    </td>
                    </tr>
            </table>
          </form>
         </body>
</html>


<?php


?>



