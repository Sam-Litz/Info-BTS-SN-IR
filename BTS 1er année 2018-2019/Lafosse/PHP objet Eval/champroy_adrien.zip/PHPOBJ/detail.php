<?php

class personne{
private $nom;
private $prenom;
private $age;
private $profession;
private $sexe;
private $passions;
private $nationalite;
}


        

