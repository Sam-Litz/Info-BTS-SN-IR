<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class  Personne {
    
    private $_Nom;
    private $_Prenom;
    private $_Age;
    private $_Profession;
    private $_Feminin;
    private $_Masculin;
    private $_Musique;
    private $_Sport;
    private $_Jeux;
    private $_Nationalite;
    
    function get_Nom() {
        return $this->_Nom;
    }

    function get_Prénom() {
        return $this->_Prénom;
    }

    function get_Age() {
        return $this->_Age;
    }

    function get_Profession() {
        return $this->_Profession;
    }

    function get_Feminin() {
        return $this->_Feminin;
    }

    function get_Masculin() {
        return $this->_Masculin;
    }

    function get_Musique() {
        return $this->_Musique;
    }

    function get_Sport() {
        return $this->_Sport;
    }

    function get_Jeux() {
        return $this->_Jeux;
    }

    function get_Nationalite() {
        return $this->_Nationalite;
    }

    function set_Nom($_Nom) {
        $this->_Nom = $_Nom;
    }

    function set_Prénom($_Prénom) {
        $this->_Prénom = $_Prénom;
    }

    function set_Age($_Age) {
        $this->_Age = $_Age;
    }

    function set_Profession($_Profession) {
        $this->_Profession = $_Profession;
    }

    function set_Feminin($_Feminin) {
        $this->_Feminin = $_Feminin;
    }

    function set_Masculin($_Masculin) {
        $this->_Masculin = $_Masculin;
    }

    function set_Musique($_Musique) {
        $this->_Musique = $_Musique;
    }

    function set_Sport($_Sport) {
        $this->_Sport = $_Sport;
    }

    function set_Jeux($_Jeux) {
        $this->_Jeux = $_Jeux;
    }

    function set_Nationalite($_Nationalite) {
        $this->_Nationalite = $_Nationalite;
    }

}