<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="Coordonées" method="POST" action="PHPOBJ/detail.php">
            <b>Merci de saisir vos coordonées</b><br><br>
            Nom : <input type="text" name="Nom" value="" placeholder="Nom"/><br><br>
            Prénom : <input type="text" name="Prénom" value="" placeholder="Prénom" /><br><br>
            Age : <input type="text" name="Age" value="" placeholder="Age"/><br><br>
            Profession : <input type="text" name="Profession" value="" placeholder="Profession" /><br><br><br>
            
            
            <b>Quel est votre sexe ?</b><br><br>
            <input type="radio" name="genre" value="masculin" checked> Masculin<br>
            <input type="radio" name="genre" value="feminin"> Feminin<br><br><br>
        
            
            <b>Quels sont vos passions ?</b><br><br>
            Musique<input type="checkbox" name="musique" value="Musique"><br>
            Sport <input type="checkbox" name="sport" value="Sport"><br>
            Jeux vidéo <input type="checkbox" name="jeux" value="Jeux"><br><br><br>
   
            
            <b>Quels est votre nationalité ?</b><br><br>
            <select>
            <option value="rancaise">Francaise</option>
            </select><br><br><br>
        
        <input type="submit" value="Afficher" name="afficher" /> 
        </form>  
    </body>
</html>
