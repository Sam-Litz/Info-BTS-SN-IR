
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>main</title>
    </head>
   
    <body>
        <form name="Coordonnees" action="detail.php" method="POST">
        
        <table border="0" width="100%" cellspacing="7">
            <thead>
                <tr>
                    <th  colspan="2">Merci de saisir vos coordonnées</th>
                    
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td width="50%" ><center>Nom : </center></td>
                    <td><input required type="text" name="Nom" value="" /></td>
                </tr>
                <tr>
                    <td><center>Prenom : </center></td>
                <td><input required="" type="text" name="Prenom" value="" /></td>
                </tr>
                <tr>
                    <td><center>Age : </center></td>
                    <td><input required="" type="number" name="Age" value="" /></td>
                </tr>
                <tr>
                    <td><center>profession : </center></td>
                    <td><input required="" type="text" name="Prefession" value="" /></td>
                </tr>
                <tr>
                    <td><center>Sexe : </center></td>
                    <td>Feminin : <input type="radio" name="sexe" value="Feminin" /></td>
                </tr>
                <tr>
                    <td></td>
                    <td>masculin : <input type="radio" name="sexe" required="" value="Masculin" /></td>
                </tr>
                <tr>
                    <td><center>quel est votre passion ?</center></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Musique<input type="checkbox" name="Musique" value="ON" /></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Sport <input type="checkbox" name="Sport" value="ON" /></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Jeux video <input type="checkbox" name="JeuxVideo" value="ON" /></td>
                    <td></td>
                </tr>
                
                <tr>
                    <td><center>quelle est votre nationalité ?</center></td>
                    <td><select name="Nationalite">
                            <option>Français</option>
                            <option>Italien</option>
                            <option>Anglais</option>
                            <option>Cannadien</option>
                            <option>Allemend</option>
                            <option>Turque</option>
                            <option>Japonais</option>
                            <option>Chinois</option>
                            <option>Russe</option>
                            <option>Belge</option>
                        </select></td>
                </tr>
                <tr>
                    <td></td>
                    <td><a href="detail.php"><input type=submit value="Afficher"/></a></td>
                </tr>
            </tbody>
        </table>

        
        
        <?php
        
        ?>
        
        </form>
    </body>
</html>
