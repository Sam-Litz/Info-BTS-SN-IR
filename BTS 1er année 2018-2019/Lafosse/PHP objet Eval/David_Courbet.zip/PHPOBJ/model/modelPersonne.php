<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of modelPersonne
 *
 * @author Utilisateur
 */
class modelPersonne {
    
    private $db;
    
    
    function __construct(){
    }
 
    
    function connexion() {
        try { //Connexion a la base de donnée
            $this->db = new PDO('mysql:host=localhost;dbname=phpobj', 'root', '');
            //Configuration du pilote pour activer les exceptions
            //$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $ex) {
            echo "Echec: " . $ex->getMessage();
        }
    }
    
    
 //lire dans ma table Equipe
    public function read() {
        $listePersonne = array();
        $res = $this->db->query("SELECT * FROM personne");
        while ($row = $res->fetch()) {
            $personne = $this->wrapper($row);
            $listePersonne[] = $personne;
        }
        //print_r($listeEquipes);
        return $listePersonne;
    }

    
    
    public function wrapper($row) {
        $personne = new Personne();
        $personne->setNom($row['nom']);
        $personne->setPrenom($row['prenom']);
        $personne->setAge($row['age']);
        $personne->setProfession($row['profession']);
        
        return $personne;
    }

    
    
    public function create($personne) {
        $stmt = $this->db->prepare("INSERT INTO personne(nom) VALUES (:nom)");
        $stmt->bindParam(':nom', $personne->getNom());
        $stmt->execute();
        $stmt = $this->db->prepare("INSERT INTO personne(prenom) VALUES (:prenom)");
        $stmt->bindParam(':prenom', $personne->getPrenom());
        $stmt->execute();
        $stmt = $this->db->prepare("INSERT INTO personne(age) VALUES (:age)");
        $stmt->bindParam(':age', $personne->getAge());
        $stmt->execute();
        $stmt = $this->db->prepare("INSERT INTO personne(profession) VALUES (profession)");
        $stmt->bindParam(':profession', $personne->getProfession());
        $stmt->execute();
    //put your code here
}
}
