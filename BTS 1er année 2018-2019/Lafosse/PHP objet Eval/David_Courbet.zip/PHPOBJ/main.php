<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        Merci de saisir vos coordonnées <br> <br> <br> <br> 
        
        <form method="post" action="detail.php">

            <p>Nom : <input type="text" name="Nom"/> <br> <br> <br>
                Prenom : <input type="text" name="Prenom"/> <br> <br> <br>
                Age : <input type="text" name="Age"/> <br> <br> <br>
                Profession : <input type="text" name="Profession"/> <br> <br> <br> 
            </p>

</form>
        
        
        <form method="post" action="detail.php">
        Quel est votre sexe ? <br/> <br> <br> 

 HOMME : <input type="radio" name="sexe" value="HOMME"><br/> <br> 
 FEMME : <input type="radio" name="sexe" value="FEMME"><br/> <br> <br> <br>
        </form>
 
        <form method="post" action="detail.php">
 Quelles sont vos passions ? <br> <br> <br>
        
 Musique : <input type="checkbox" name="activite" value="Musique"><br/> <br>
 Sport : <input type="checkbox" name="activite" value="Sport"><br/> <br>
 Jeux video : <input type="checkbox" name="activite" value="Jeux video" checked="checked"><br/> <br> <br> <br>
        </form>
 
 Quelle est votre nationalité ? <br><br><br> 

<FORM>
<SELECT name="nom" size="1">
<OPTION selected>Française
<OPTION>Canadienne
</SELECT>
</FORM>
 
 
    <center> <a href="detail.php"> <input type="button" value="Afficher"> </a></center>
       

    </body>
</html>
