<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Passion
 *
 * @author Utilisateur
 */
class Passion {
    //put your code here
    private $musique;
    private $sport;
    private $jeuxvideo;
    
    function getMusique() {
        return $this->musique;
    }

    function getSport() {
        return $this->sport;
    }

    function getJeuxvideo() {
        return $this->jeuxvideo;
    }


           
}
