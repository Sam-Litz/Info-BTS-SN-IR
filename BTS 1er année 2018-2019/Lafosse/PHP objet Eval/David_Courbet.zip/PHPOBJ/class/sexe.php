<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of sexe
 *
 * @author Utilisateur
 */
class sexe {
    
    
    private $masculin = 1;
    private $feminin = 0; 
    //put your code here
    
    function getMasculin() {
        return $this->masculin;
    }

    function getFeminin() {
        return $this->feminin;
    }

    function setMasculin($masculin) {
        $this->masculin = $masculin;
    }

    function setFeminin($feminin) {
        $this->feminin = $feminin;
    }


    
    
}
