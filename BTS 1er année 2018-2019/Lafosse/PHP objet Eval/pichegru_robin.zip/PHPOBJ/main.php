<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <div>Merci de saisir vos coordonnées</div><br>
        
        <form action="retail.php" method="POST">
        
            <label for="Nom">Nom : </label><input type="text" value="" name="nom"/><br/><br>
            <label for="prénom">Prénom : </label><input type="text" value="" name="prénom"/><br/><br>
            <label for="adressemail">Age: </label><input type="text" value="" name="age"/><br/><br>
            <label for="ville">Profession : </label><input type="text" value="" name="profession"/><br/><br><br>
          
            <div>Quel est votre sexe ?</div><br>

            <input type="radio" name="sexe" value="HOMME"> Féminin<br/>
            <input type="radio" name="sexe" value="FEMME"> Masculin<br/><br>
            
            <div>Quelles sont vos passions ?</div><br>
            
            Musique : <input type="checkbox" name="activite" value="SPORT"><br/><br>
            Sport : <input type="checkbox" name="activite" value="MUSIQUE"><br/><br>
            Jeux Vidéo : <input type="checkbox" name="activite" value="CINEMA"><br/><br>
            
            <div>Quelle est votre nationalité ?</div><br>

            <select  style="width:120px;" autofocus name="date">
	<option value="">Française</option>
        <option value="12">Anglaise</option>
        <option value="12">Islandaise</option>
        <option value="12">Portugaise</option>
        <option value="12">Roumaine</option>
            </select><br><br><br>
            <input type="submit" value="Afficher"/>

        
        </form>
     
    </body>
    
    
          
</html>
