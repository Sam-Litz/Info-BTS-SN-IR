<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>TODO supply a title</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <form>
        <br/>
            <div>Merci de saisir vos coordonnées</div>
        <br/>
        
        <form name="Authentification" method="POST" action="PHPOBJ/main.php">
        
        Nom : <input type="text" name="Nom"/><br/>
        <br/>
        Prénom : <input type="text" name="Prénom"/><br/>
        <br/>
        Age : <input type="text" name="Age"/><br/>
        <br/>
        Profession : <input type="text" name="Profession"/><br/>
        
        <br/>
        <br/>
            <div>Quelle est votre sexe?</div>
        <br/>
        
        <input type="radio" name="sexe" value="Femme"> Feminin<br/>
        <input type="radio" name="sexe" value="Homme"> Masculin<br/>

        <br/>
            <div>Quelles sont vos passions?</div>
        <br/>
        
        Musique <input type="checkbox" name="passions" value="Musique"><br/>
        Sport <input type="checkbox" name="passions" value="Sport"><br/>
        Jeux vidéo <input type="checkbox" name="passions" value="Jeux vidéo"><br/>
        
        <br/>
        <br/>
            <div>Quelle est votre nationalité?</div>
        <br/>
        
        <select name="nationalité">
	<option value="Française" selected="selected">Française</option>
        <option value="Anglaise">Anglaise</option>
        <option value="Allemande">Allemande</option>
        <option value="Italienne">Italienne</option>
        <option value="Espagnole">Espagnole</option>
        <option value="Portugaise">Portugaise</option>
        </select>
        
        <br/>
        <br/>

        <input type="submit" name="valider" value="Afficher"/>
        </form>
        <?php
        if(isset($_POST['valider'])){
            $Nom=$_POST['Nom'];
            $Prénom=$_POST['Prénom'];
            $Age=$_POST['Age'];
            $Profession=$_POST['Profession'];
            $sexe=$_POST['sexe'];
            $passions=$_POST['passions'];
            $nationalité=$_POST['nationalité'];
            echo 'Merci voici votre fiche '. $pseudo.'de '. $ville.'<br/>Bienvenue sur mon site !';
        }
        ?>

    </body>
</html>
